data:extend({
	{
    type = "recipe",
    name = "wooden-wall",
	 energy_required = 2,
    enabled = true,
    ingredients = 
	{
	   {"wood", 5}
	},
    result = "wooden-wall",
    }
})
