data:extend({
{
    type = "recipe",
    name = "speedy-assembling-machine",
    enabled = false,
    ingredients =
    {
      {"iron-plate", 10},
      {"iron-gear-wheel", 20},
      {"red-assembling-machine", 2},
	  {"uranium-235", 1}
    },
    result = "speedy-assembling-machine"
  },
{
    type = "recipe",
    name = "red-assembling-machine",
    enabled = false,
    ingredients =
    {
      {"iron-plate", 10},
      {"iron-gear-wheel", 10},
      {"assembling-machine-2", 2}
    },
    result = "red-assembling-machine"
  }
})
