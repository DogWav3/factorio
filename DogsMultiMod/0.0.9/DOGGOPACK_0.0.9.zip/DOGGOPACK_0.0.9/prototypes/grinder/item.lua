data:extend({
	{
		type = "item",
		name = "iron-pouder",
		icon = "__DOGGOPACK__/prototypes/grinder/g/ip.png",
		icon_size = 128,
		stack_size = 20,
		subgroup = "ammo",
	},
	{
		type = "item",
		name = "copper-pouder",
		icon = "__DOGGOPACK__/prototypes/grinder/g/cp.png",
		icon_size = 128,
		stack_size = 20,
		subgroup = "ammo",
	},
})
